import pickle


def load_pickled_data(file_name):
    """ Load Data"""
    file = open(file_name, "rb")
    data = pickle.load(file)
    file.close()
    return data


def save_pickled_data(file_name, data):
    """ Save Data """
    file = open(file_name, "wb")
    pickle.dump(data, file)
    file.close()
    return True
