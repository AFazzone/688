# https://qa.fastforwardlabs.com/pytorch/hugging%20face/wikipedia/bert/transformers/2020/05/19/Getting_Started_with_QA.html
# import torch
# from transformers import AutoModel, AutoTokenizer
from collections import OrderedDict
from tqdm import tqdm
from sklearn.feature_extraction.text import CountVectorizer

import spacy
from spacy.lang.en.stop_words import STOP_WORDS
from collections import Counter

from string import punctuation
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.tokenize import sent_tokenize
from heapq import nlargest
from app import kw_functions as kw
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
import spacy
# from keybert import KeyBERT
import regex as re

# class DocumentEmbedder:
#     def __init__(self, pretrained_model_name_or_path):
#         self.READER_PATH = pretrained_model_name_or_path
#         self.tokenizer = AutoTokenizer.from_pretrained(self.READER_PATH)
#         self.model = AutoModel.from_pretrained(self.READER_PATH)
#         self.max_len = self.model.config.max_position_embeddings
#         self.chunked = False
#
#     def tokenize(self, text):
#         self.chunked = False
#         self.tokens = self.tokenizer(text, add_special_tokens=True, padding=True, return_tensors="pt")
#         self.input_ids = self.tokens["input_ids"].tolist()[0]
#
#         if len(self.input_ids) > self.max_len:
#             self.tokens = self.chunkify()
#             self.chunked = True
#
#     def chunkify(self):
#         """
#         Break up a long article into chunks that fit within the max token requirement for that Transformer model.
#
#         Calls to BERT / RoBERTa / ALBERT require the following format:
#         [CLS] question tokens [SEP] context tokens [SEP].
#         """
#
#
#         qmask = self.tokens['attention_mask'].lt(10)
#         qt = torch.masked_select(self.tokens['input_ids'], qmask)
#         chunk_size = self.max_len - 3
#
#         # create a dict of dicts; each sub-dict mimics the structure of pre-chunked model input
#         chunked_input = OrderedDict()
#         for k, v in self.tokens.items():
#             # q = torch.masked_select(v, qmask)
#             c = torch.masked_select(v, qmask)
#             chunks = torch.split(c, chunk_size)
#
#             for i, chunk in enumerate(chunks):
#                 if i not in chunked_input:
#                     chunked_input[i] = {}
#
#                 # thing = torch.cat((q, chunk))
#                 thing = chunk
#                 if i != len(chunks) - 1:
#                     if k == 'input_ids':
#                         thing = torch.cat((thing, torch.tensor([102])))
#                     else:
#                         thing = torch.cat((thing, torch.tensor([1])))
#
#                 chunked_input[i][k] = torch.unsqueeze(thing, dim=0)
#         return chunked_input
#
#     def get_embeddings(self):
#         if self.chunked:
#             embedded_text = list()
#             for k, chunk in tqdm(self.tokens.items(), desc="Getting Embeddings from Text Chunks"):
#                 text_embedding = self.model(**chunk)["pooler_output"]
#                 embedded_text.append(text_embedding.detach().numpy())
#             return embedded_text
#         else:
#             embedded_text = list()
#             text_embedding = self.model(**self.tokens)["pooler_output"]
#             embedded_text.append(text_embedding.detach().numpy())
#             return embedded_text
#
#
# """ Text Processing Functions """
# import regex as re


def custom_preprocessor(text):
    text = text.lower()  # lowering the text case
    text = re.sub("\\W", " ", text)  # remove special chars
    text = re.sub(r'\d+', ' ', text)  # Remove Numbers
    return text


def tokenize_content(doc_content):
    """ Candidate Token Selection using spaCy """
    n_gram_range = (1, 2)
    stop_words = "english"

    """ Extract candidate words/phrases using NLTK """
    count = CountVectorizer(ngram_range=n_gram_range, stop_words=stop_words, preprocessor=custom_preprocessor).fit([doc_content])
    all_candidates = count.get_feature_names()

    nlp = spacy.load('en_core_web_sm')
    doc = nlp(doc_content)
    noun_phrases = set(chunk.text.strip().lower() for chunk in doc.noun_chunks)  # Phrases containing Nouns

    nouns = set()
    for token in doc:
        if token.pos_ == "NOUN":
            nouns.add(token.text)  # Create set of Nouns

    all_nouns = nouns.union(noun_phrases)

    # Candidate selection process
    # Filter the earlier list of all candidates and including only those that are in the all nouns set
    candidates = list(filter(lambda candidate: candidate in all_nouns, all_candidates))

    return candidates


def extract_kw_bert(doc_content, candidates, model_name):
    """
        Vectorize Content - a single vector
        Vectorize Keyword Candidates - vector for each keyword
        Extract most similar (cosine similarity) Keyword Candidates as Keywords
    """

    """ Select Transformer Models """
    reader = DocumentEmbedder(model_name)

    """ 1 Embed Content """
    reader.tokenize(doc_content)
    embedded_text = reader.get_embeddings()

    """ 2 Embed KeyWord Candidates """
    reader.tokenize(candidates)
    embedded_keywords = reader.get_embeddings()

    """ 3 Extract KeyWords. Use cos-similarity score between embedded text and the embedded KeyWord Candidates """
    top_k = 5
    chunk_kw_scores = np.empty(shape=(0, 2))
    for text_chunks in range(len(embedded_text)):
        distances = cosine_similarity(embedded_text[text_chunks], embedded_keywords[0])

        # Select top 5 keywords and their indices
        indices = [index for index in distances.argsort()[0][-top_k:]]
        keywords = [candidates[ix] for ix in indices]

        # Create Numpy array of the 5 keywords and their scores for each content chunk
        chunk_kw = np.array(keywords);
        chunk_scores = distances[0][indices];
        temp = np.array(list(zip(chunk_kw, chunk_scores)))
        chunk_kw_scores = np.vstack((chunk_kw_scores, temp))

        # keyword_list += keywords

    # Re-order by top score extracted KW from different chunks
    ord = chunk_kw_scores[:, 1].argsort()
    scores_sorted = chunk_kw_scores[ord]

    """ If same keywords appear in multiple content chunks, Select keyword with max score """
    unique_keywords = list(np.unique(scores_sorted[:, 0]))
    top_keywords = np.empty(shape=(0, 2))
    for val in unique_keywords:
        """ Loop over each unique keyword and select max score if that keyword appeared more than once """
        itemindex = np.where(scores_sorted[:, 0] == val)
        # Turn Numpy array and its score which is a list of strings to a float list to find the max
        temp1 = scores_sorted[itemindex, 1]
        temp1_str = list(temp1.flatten())
        temp1_float = [float(i) for i in temp1_str]
        max_val = max(temp1_float)

        # Reconstruct values into Numpy array
        kw_val = np.array([val])
        kw_score = np.array([max_val])
        temp = np.array(list(zip(kw_val, kw_score)))
        top_keywords = np.vstack((top_keywords, temp))

    # Order keywords by their max score and select the top 5
    ord = top_keywords[:, 1].argsort()
    keywords_5 = top_keywords[ord, :][-top_k:]

    return keywords_5

def extract_kw_keybert(doc_content):
    """ Using spacy-transformer models """
    spacy.prefer_gpu()
    nlp = spacy.load("en_core_web_sm", exclude=['tagger', 'parser', 'ner', 'attribute_ruler', 'lemmatizer'])
    model = KeyBERT(model=nlp)
    keywords5 = model.extract_keywords(doc_content, keyphrase_ngram_range=(3, 3), stop_words='english', use_maxsum=True, nr_candidates=20, top_n=5)
    return keywords5


class SummarizeSpaCy(object):
    """ Text Summarization using spayCy
    Summarize Document by summarizing each section
    This Class accepts two input arguments:
        text — The input text (a short paragraph or a big chunk of text)
        limit — The number of sentences to be returned.
    """

    """ Class Variables """
    count = 0  # For All Instances

    def __init__(self):
        """   Class Attributes   """
        SummarizeSpaCy.count += 1
        self.word_frequencies = list()
        self.sentence_scores = {}
        self.summary = ""

    """ Class Methods Declaration """
    def tokenize_text(self, text):
        """   Instance Variables: word_frequencies  """
        nlp = spacy.load('en_core_web_sm')  # Load the model (English) into spaCy
        doc = nlp(text)

        """ 1) Tokenize the input text and find out the important tokens ("keywords") in it  
                1 — Convert the input text to lower case and tokenize it with spaCy’s language model.
                2 — Loop over each of the tokens.
                3 — Ignore the token if it is a stopword or punctuation.
                4 — Append the token to a list if it is the part-of-speech tag that we have defined.
        """
        keyword = []  # Tokens
        pos_tag = ['PROPN', 'ADJ', 'NOUN', 'VERB']
        doc = nlp(text.lower())  # 1
        for token in doc:  # 2
            if token.text in nlp.Defaults.stop_words or token.text in punctuation:
                continue  # 3
            if token.pos_ in pos_tag:
                keyword.append(token.text)  # 4

        """ 2) Normalize token's ("keywords") weight  
                for better processing by dividing the token’s frequencies by the maximum frequency. """
        self.word_frequencies = Counter(keyword)  # Counter will convert the list into a dictionary with their respective frequency values.
        max_freq = Counter(keyword).most_common(1)[0][1]  # Get the frequency of the top most-common keyword.
        for w in self.word_frequencies:
            self.word_frequencies[w] = (self.word_frequencies[w] / max_freq)  # Loop over each item in the dictionary and normalize the frequency.

        return self

    def find_sent_strength(self, text):
        """   Instance Variables: sentence_scores """
        """ 3) Calculate the importance of the sentences ("sentence_scores") by identifying the occurrence of 
        important keywords and sum up the value. """
        """ Weigh each sentence based on the frequency of the keywords present in each of the sentences. """
        nlp = spacy.load('en_core_web_sm')  # Load the model (English) into spaCy
        doc = nlp(text)
        for sent in doc.sents:  # Loop over each sentence in the text, that are split by the spaCy model based on full-stop punctuation.
            for word in sent:  # Loop over each word in a sentence based on spaCy’s tokenization.
                if word.text in self.word_frequencies.keys():  # Determine if the word is a keyword based on the keywords that we extracted earlier.
                    if sent in self.sentence_scores.keys():
                        # Add normalized keyword value to the key-value pair of the sentence.
                        self.sentence_scores[sent] += self.word_frequencies[word.text]
                    else:
                        # Create a new key-value in the sentence_scores dictionary using the sentence as key
                        # and the normalized keyword value as value.
                        self.sentence_scores[sent] = self.word_frequencies[word.text]
        return self

    def summarize(self, limit):
        """   Instance Variables: summary   """
        """ 4) Generate the Summary """
        temp_summary = []
        # Sort the dictionary based on the normalized value. Set the reverse parameter to True for descending order.
        sorted_x = sorted(self.sentence_scores.items(), key=lambda kv: kv[1], reverse=True)

        counter = 0
        for i in range(len(sorted_x)):  # Loop over each of the sorted items.
            temp_summary.append(str(sorted_x[i][0]).capitalize())  # 15
            counter += 1
            if counter >= limit:
                break  # Break out of the loop if the counter exceeds the limit

        # self.summary = ' '.join(temp_summary)  # Return the list as a string by joining each element with a space.

        return ' '.join(temp_summary)


def summarize_content(section_content, potential_concepts, num_sentences):
    """ 3) Summarize Content using spaCy """
    spaCy_summarizer = SummarizeSpaCy()

    """ Get words & sentence strength """
    freq_words = spaCy_summarizer.tokenize_text(section_content)  #
    sent_strength = spaCy_summarizer.find_sent_strength(section_content)  #
    section_content = spaCy_summarizer.summarize(num_sentences)  # Summarize

    """ Select concepts that are not in candidates but are in summary """
    section_kw_candidates = tokenize_content(section_content)
    section_concepts = [val for val in potential_concepts if val not in section_kw_candidates and val in section_content]
    spaCy_kw = [key for key in sent_strength.word_frequencies if key not in section_kw_candidates and key in section_content]

    return section_content, section_kw_candidates, section_concepts, spaCy_kw


