
doc_breast_cancer = """
Breast cancer in women.
This malignancy of the breast tissue is the most common malignancy diagnosed in women worldwide.
Background.
Breast cancer is a malignancy of the breast tissue and is the most common malignancy diagnosed in women worldwide.
Early or operable breast cancer is considered potentially curable and includes stage I-IIB and some stage IIIA cancers, specifically T3, N1 tumors.
Noninflammatory locally advanced inoperable breast cancer is considered potentially curable and includes stage IIIA-C breast tumors with the exception of some stage IIIA, specifically T3, N1 tumors.
Inflammatory breast cancer is a rare, aggressive subtype of locally advanced breast cancer characterized by a substantial area of breast skin that is red in color, warm, and thickened or swollen (referred to as peau d'orange).
Advanced (metastatic) breast cancer encompasses disease that has spread beyond the breast and regional lymph nodes and is either de novo stage IV (metastatic at the time of initial diagnosis) or a metastatic recurrence. Common sites of metastases include bone, liver, lung, and brain.
Risk factors for breast cancer include genetic causes, increased age, reproductive history and hormone exposure, lifestyle factors, medical history, and radiation exposure.
Women with breast cancer may present with breast abnormalities detected during screening, without any other signs or symptoms. Common signs and symptoms of breast cancer include palpable breast mass, axillary mass, nipple discharge, skin changes on breast or nipple, asymmetric thickening or nodularity, breast pain, or signs and/or symptoms due to metastatic disease.
The 5-year survival after diagnosis of breast cancer is 99% for women with localized disease, 85% for women with regional spread, and 27% for women with distant metastases in the United States; in addition, women with estrogen receptor positive cancers treated with endocrine therapy have a 13%-41% risk of recurrence 5-20 years after diagnosis. Factors affecting prognosis include tumor and disease characteristics, age, response to therapy, race and ethnicity, and body mass.
Evaluation.
Diagnosis is based on examination of the breast and axillary lymph nodes with clinical exam and imaging, and confirmed by the pathological assessment of biopsy.
Perform imaging including either or both diagnostic mammogram and ultrasound (Strong recommendation); magnetic resonance imaging (MRI) of breast may also be used in specific circumstances. Recommendations for specific imaging tests vary based on presentation.
Pathological assessment of breast is generally performed using core needle biopsy, preferably with ultrasound or stereotactic guidance (Strong recommendation); also perform ultrasound-guided fine needle aspiration or core needle biopsy of suspicious lymph nodes (Strong recommendation).
Consider testing to assess for distant metastatic disease in patients with inoperable breast cancer and in symptomatic or high-risk patients with operable breast cancer including blood tests, chest computed tomography (CT), abdominal ultrasound or abdominal with or without pelvic CT with contrast or magnetic resonance imaging, bone scan, or fluorodeoxyglucose positron emission tomography (PET)/CT (Weak recommendation).
Description.
Breast cancer is a malignancy of the breast tissue and is the most common malignancy diagnosed in women worldwide. 
"""


