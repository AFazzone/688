import pickle

file_name = "Test_file.txt"
doc = ["The regular early morning yell of horror was the sound of Authur",
       "Dent waking up and suddenly remembering where he was. It wasn!t",
       "just that the cave was cold, it wasn!t just that it was damp and",
       "smelly. It was the fact that the cave was in the middle of",
       "Islington and there wasn!t a bus due for two million years."]

""" Save Data into Pickle file """
file = open("temp.dat", 'wb')
pickle.dump([file_name, doc], file)
file.close()


print("End")


