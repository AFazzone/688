# spaCy Link - https://realpython.com/natural-language-processing-spacy-python/
from app import text_samples as ts
import spacy
from spacy import displacy
from collections import Counter

nlp = spacy.load('en_core_web_sm')

# Get text on Breast Cancer
breast_cancer = ts.doc_breast_cancer
doc = nlp(breast_cancer)

# Sentence Detection - divide text into linguistically meaningful units.
sentences = list(doc.sents)
len(sentences)

# Tokenization - identify the basic units in your text.
for token in doc:
    print(token, token.idx)

# Stop Words
spacy_stopwords = spacy.lang.en.stop_words.STOP_WORDS
len(spacy_stopwords)

for stop_word in list(spacy_stopwords)[:10]:
    print(stop_word)

# Lemmatization - the process of reducing inflected forms of a word while still ensuring that
# the reduced form belongs to the language.
# For example, organizes, organized and organizing are all forms of organize.
# Lemmatization is necessary because it helps you reduce the inflected forms of a word so that they can
# be analyzed as a single item.
for token in doc:
    print(token, token.lemma_)

# Word Frequency
# Remove stop words and punctuation symbols
words = [token.text for token in doc
         if not token.is_stop and not token.is_punct]
word_freq = Counter(words)
# 5 commonly occurring words with their frequencies
common_words = word_freq.most_common(5)
print(common_words)

# Unique words
unique_words = [word for (word, freq) in word_freq.items() if freq == 1]
print(unique_words)

# By looking at the common words, you can see that the text as a whole is probably about
# [('breast', 24), ('\n', 19), ('cancer', 14), ('women', 8), ('malignancy', 6)]

# Part of Speech Tagging - a grammatical role that explains how a particular word is used in a sentence.
# There are eight parts of speech:
#
# Noun
# Pronoun
# Adjective
# Verb
# Adverb
# Preposition
# Conjunction
# Interjection

# Part of speech tagging is the process of assigning a POS tag to each token depending on its usage in the sentence.
for token in doc:
    print(token, token.tag_, token.pos_, spacy.explain(token.tag_))

# Visualization: Using displaCy
sentence_doc = nlp(sentences[2].text_with_ws)
displacy.serve(sentence_doc, style='dep')
# To See the HTML use http://127.0.0.1:5000/ or  http://localhost:5000


print("End")
