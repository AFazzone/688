# https://towardsdatascience.com/building-a-question-answering-system-part-1-9388aadff507
from app import text_samples as ts
import spacy
from spacy.matcher import Matcher
from nltk import Tree

from nltk.stem.lancaster import LancasterStemmer
st = LancasterStemmer()

nlp = spacy.load('en_core_web_sm')

# Get text on Breast Cancer
breast_cancer = ts.doc_breast_cancer
doc = nlp(breast_cancer)

# Sentence Detection - divide text into linguistically meaningful units.
doc_sents = list(doc.sents)
len(doc_sents)

# 1) Plot Dependency Parse Tree for a Sentence
def to_nltk_tree(node):
    if node.n_lefts + node.n_rights > 0:
        return Tree(node.orth_, [to_nltk_tree(child) for child in node.children])
    else:
        return node.orth_


print(doc_sents[2].text)
to_nltk_tree(doc_sents[2].root).pretty_print()

# 2) Print Roots of second sentence
print([st.stem(chunk.root.head.text.lower()) for chunk in doc_sents[2].noun_chunks])

# 2) Get the Roots of All the Sentences in the Paragraph
for sent in doc_sents:
    roots = [st.stem(chunk.root.head.text.lower()) for chunk in sent.noun_chunks]
    print(roots)


# 3) Extract Verbs
sentence = doc_sents[2]
pattern = [{'POS': 'VERB', 'OP': '?'},
           {'POS': 'ADV', 'OP': '*'},
           {'OP': '*'},  # additional wildcard - match any text in between
           {'POS': 'VERB', 'OP': '+'}]

# instantiate a Matcher instance
matcher = Matcher(nlp.vocab)

# Add pattern to matcher
matcher.add("verb-phrases", [pattern])
doc = nlp(sentence.text)
# call the matcher to find matches
matches = matcher(doc)
spans = [doc[start:end] for _, start, end in matches]

print(doc)
print("The Verb:", spans[-1])

# 4) Match words
doc1 = nlp(u"BreastCancer in women. " \
           "The breast cancer is the most common malignancy diagnosed in women worldwide. " \
           "The breast-cancer is a malignancy of the breast tissue.")

pattern1 = [{'LOWER': 'solarpower'}]
pattern2 = [{'LOWER': 'solar'}, {'IS_PUNCT': True}, {'LOWER': 'power'}]
pattern3 = [{'LOWER': 'solar'}, {'LOWER': 'power'}]

matcher.add('BreastCancer', [pattern1, pattern2, pattern3])
found_matches = matcher(doc1)


for _,start,end in found_matches:
    span = doc[start:end]
    print(span)

print("End")



