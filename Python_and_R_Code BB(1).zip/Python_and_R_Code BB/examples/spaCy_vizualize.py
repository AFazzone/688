# spaCy Example
# See: https://spacy.io/usage/visualizers
import spacy
from spacy import displacy
from app import text_samples as ts

nlp = spacy.load("en_core_web_sm")
doc = ts.doc_breast_cancer  # Read the
sent_1 = nlp(doc.split("\n")[1])  # Take a sentence from the document content
sent_2 = nlp(doc.split("\n")[2])

displacy.serve(sent_1, style="dep")  # Display sentence 1 grammar
# To See the HTML use this URL in your Browser http://127.0.0.1:5000/ or  http://localhost:5000

# Save 2 sentences grammar display as HTML file
doc1 = sent_1
doc2 = sent_2
html_content = displacy.render([doc1, doc2], style="dep", page=True)
Html_file = open("spaCy_example.html", "w")
Html_file.write(html_content)
Html_file.close()

print("End")

