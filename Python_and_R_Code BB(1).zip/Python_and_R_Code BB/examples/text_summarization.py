from gensim.summarization import summarize
from app import text_samples as ts
from app import kw_functions as kw

# Get text on Breast Cancer
doc_content = ts.doc_breast_cancer

""" Summarize using Gensim """
summary_Gensim = summarize(doc_content, ratio=0.5)

""" Summarize using spaCy """
spaCy_summarizer = kw.SummarizeSpaCy()
freq_words = spaCy_summarizer.tokenize_text(doc_content)
sent_strength = spaCy_summarizer.find_sent_strength(doc_content)
summary_spaCy = spaCy_summarizer.summarize(5)


print("End")

