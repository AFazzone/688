# Using Python with R 
rm(list=ls()); cat("\014") # Clear Workspace and Console
library(reticulate) # Load the package

# List all Conda environments and choose which one to use
my_env <- conda_list()
use_condaenv(my_env$name[1], required = TRUE)
use_python(my_env$python[1], required = TRUE)
Sys.which("python")

# Load Data saved with Python 
# Python package location: C:\Users\zlatk\Anaconda3\Lib\site-packages 
# sp <- import("spacy")

# Import Python package "pickle"
pi <- import("pickle")
# Set the path to the custom python script file that reads the content of the Python data file
path2python_script <- "Python_Code/app/common_functions.py"
# Source (execute) this Python script file 
source_python(path2python_script)
# Load the data into R 
pickled_data <- load_pickled_data('Python_Code/temp.dat')


# spaCy examples 
# https://spacy.io/usage/spacy-101 





