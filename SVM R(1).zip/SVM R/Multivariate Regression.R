#  Multivariate Regression
rm(list=ls()); cat("\014") # clear all
library(e1071)

csv.data <- read.csv('regression.csv', header = TRUE)
Y <- csv.data$Y # Independent Data 
X1 <- csv.data$X # Dependent Data
X2 <- 70 - X1/2 # Dependent Data

plot(X1,Y)
plot(X2,Y)

Dep.Data <- data.frame(X1, X2)
Train.Data <- data.frame(Indep.Data=Y, Dep.Data=Dep.Data)

# Create the Model
model <- svm(Indep.Data ~ ., Train.Data) # Create the Multyvariate SVM Model
model <- svm(Indep.Data ~ X1+X2, Train.Data) # Create the Multyvariate SVM Model
# print(model)
# summary(model)

# Make predictions From the Model with train data
predictedY <- predict(model, Train.Data)

# Estimate Root Mean Square Errors (EMSE)
rmse <- function(error) {
  sqrt(mean(error^2))
}

error <- Y - predictedY  # 
svrPredictionRMSE <- rmse(error) # 3.157061
# Check accuracy:
# table(predictedY, Y)

# Plot X1 - Predictions
points(X1, predictedY, col = "red", pch=17)
lines(X1, predictedY, col = "dark red", pch=4)

# Plot X2 - predictions
points(X2, predictedY, col = "red", pch=17)
lines(X2, predictedY, col = "dark red", pch=4)

# test:
XX1 <- c(3.3, 10.5, 16.7)
newdata <- data.frame(X1 = XX1, X2 = 70 - XX1/2)
predictedY.New <- predict(model, newdata)
points(newdata$X1, predictedY.New, col = "green", pch=8)
points(newdata$X2, predictedY.New, col = "green", pch=8)



