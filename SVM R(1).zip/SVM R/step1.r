
# Load the data from the csv file
data <- read.csv('regression.csv', header = TRUE)

# Plot the data 
plot(data, pch=16)
# lines(data, col="dark red", pch=16)

# Create a linear regression model
model <- lm(Y ~ X, data)

# Add the fitted line
abline(model)
