
library(e1071)
data <- read.csv('regression.csv', header = TRUE)

rmse <- function(error)
{
  sqrt(mean(error^2))
}


plot(data, pch=16)
 

# linear model ==============================================
model <- lm(Y ~ X , data)
  
predictedY <- predict(model, data) 
points(data$X, predictedY, col = "blue", pch=4)   


error <- model$residuals  # same as data$Y - predictedY
predictionRMSE <- rmse(error)   # 3.157061 
# end of linear model =======================================


plot(data, pch=16)

# svm model ==============================================
if(require(e1071)){ 
  model <- svm(Y ~ X , data)
  model1 <- svm(data$X, data$Y)
  
  predictedY <- predict(model, data)
  predictedY1 <- predict(model1, data$X)
   
  points(data$X, predictedY, col = "red", pch=4)
  lines(data$X, predictedY, col = "dark red", pch=4)
  
  # /!\ this time  svrModel$residuals  is not the same as data$Y - predictedY
  # so we compute the error like this
  error <- data$Y - predictedY  
  svrPredictionRMSE <- rmse(error)  # 3.157061 
} 

# end of svr model =======================================


