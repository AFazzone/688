# https://towardsdatascience.com/how-to-use-bert-from-the-hugging-face-transformer-library-d373a22b0209
"""
 2) Language Modeling
 Language Modeling is the task of predicting the best word to follow or continue a sentence given all the words already in the sentence.

 Predicts next word
"""

from transformers import BertLMHeadModel, BertTokenizer
import torch
from torch.nn import functional as F

# Define Model & tokenizer
model_name = "bert-base-uncased"  # Bert on HF
tokenizer = BertTokenizer.from_pretrained(model_name)
model = BertLMHeadModel.from_pretrained(model_name, return_dict=True, is_decoder=True)

text = "Home Sweet "
input = tokenizer.encode_plus(text, return_tensors="pt")
output = model(**input).logits[:, -1, :]
softmax = F.softmax(output, -1)
index = torch.argmax(softmax, dim=-1)
x = tokenizer.decode(index)
print(x)

print("End")


