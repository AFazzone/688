# https://www.tensorflow.org/text/guide/word_embeddings

"""
 3) Sentiment Analysis of the IMDb Dataset
 MLM is the task of predicting (decoding) a masked token in a sentence.

 Produces the top 5 replacement words for the mask token
"""

import io
import os
import re
import shutil
import string
import tensorflow as tf

from keras.models import Sequential
from keras.layers import Dense, Embedding, GlobalAveragePooling1D
from tensorflow.keras.layers import TextVectorization

from tensorflow.keras.layers.experimental.preprocessing import TextVectorization

from tensorflow.keras.layers import TextVectorization




from tensorflow.keras.layers import TextVectorization


print("End")

