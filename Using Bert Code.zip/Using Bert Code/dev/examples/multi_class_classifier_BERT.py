# https://towardsdatascience.com/bert-for-dummies-step-by-step-tutorial-fb90890ffe03
"""
Use a BERT Model for solving a classification task.

Uses ATIS dataset (Airline Travel Information System) obtained from: https://www.kaggle.com/siddhadev/ms-cntk-atis
"""

import app.project_functions as pf
import matplotlib.pyplot as plt
import numpy as np
import tensorflow as tf
from tensorflow import keras
from keras import layers
import pandas as pd


DATA_DIR = "../../data/atis/"

# 1) Load ATIS training dataset
t2i_train, s2i_train, in2i_train, i2t_train, i2s_train, i2in_train, \
input_tensor_train, target_tensor_train, \
query_data_train, intent_data_train, intent_data_label_train, slot_data_train = pf.load_atis(DATA_DIR + 'atis.train.pkl')

# Load ATIS testing dataset
t2i_test, s2i_test, in2i_test, i2t_test, i2s_test, i2in_test, \
input_tensor_test, target_tensor_test, \
query_data_test, intent_data_test, intent_data_label_test, slot_data_test = pf.load_atis(DATA_DIR + 'atis.test.pkl')

# 2) Create Tensors - by padding each query vector and slot vector to a maximum length.
# Queries is already tokenized and a vocabulary is also provided in the ATIS dataset.
# Queries have a start (“BOS”) and end (“EOS”) token.
input_data_train, teacher_data_train, target_data_train, \
len_input_train, len_target_train = pf.create_tensors(input_tensor_train, target_tensor_train)
input_data_test, teacher_data_test, target_data_test, \
len_input_test, len_target_test = pf.create_tensors(input_tensor_test, target_tensor_test, max_len=len_input_train)

vocab_in_size, vocab_out_size = pf.get_vocab_size(t2i_train, t2i_test, s2i_train, s2i_test)


# Histogram of the ATIS training dataset that has 26 distinct intents.
labels = intent_data_label_train
plt.hist(labels)
plt.xlabel('intent')
plt.ylabel('nb samples')
plt.title('intent distribution')
plt.xticks(np.arange(len(np.unique(labels))))
plt.show()

# 2) Multi-class classifier - implement a simple LSTM recurrent network for solving the classification task.

BUFFER_SIZE = len(input_data_train)
BATCH_SIZE = 64
embedding_dim = 256
units = 1024
model_lstm = keras.Sequential()
model_lstm.add(layers.Embedding(vocab_in_size, embedding_dim, input_length=len_input_train))
model_lstm.add(layers.LSTM(units))
model_lstm.add(layers.Dense(nb_labels, activation='softmax'))
model_lstm.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
model_lstm.summary()

history_lstm = model_lstm.fit(input_data_train, intent_data_label_cat_train,
                              epochs=10,batch_size=BATCH_SIZE)



print("End")