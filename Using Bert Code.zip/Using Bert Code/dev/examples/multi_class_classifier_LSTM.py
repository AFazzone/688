# https://towardsdatascience.com/bert-for-dummies-step-by-step-tutorial-fb90890ffe03
"""
Use a simple LSTM recurrent network for solving a classification task.
    Using Word2vec, each word is embedded as 256 dimensional vector
    The results are passed through a LSTM layer with 1024 cells.
    This 1024 outputs is passed through a Dense layer with 26 nodes and softmax activation.
    The probabilities created at the end of this pipeline are compared to the original labels using categorical crossentropy.

Uses ATIS dataset (Airline Travel Information System) obtained from: https://www.kaggle.com/siddhadev/ms-cntk-atis
"""

import app.project_functions as pf
import pandas as pd
import time

DATA_DIR = "../../data/atis/"

# 0) Load ATIS training dataset
t2i_train, s2i_train, in2i_train, i2t_train, i2s_train, i2in_train, \
input_tensor_train, target_tensor_train, \
query_data_train, intent_data_train, intent_data_label_train, slot_data_train = pf.load_atis(DATA_DIR + 'atis.train.pkl')

# Load ATIS testing dataset
t2i_test, s2i_test, in2i_test, i2t_test, i2s_test, i2in_test, \
input_tensor_test, target_tensor_test, \
query_data_test, intent_data_test, intent_data_label_test, slot_data_test = pf.load_atis(DATA_DIR + 'atis.test.pkl')

# 1) Display dataset for each intent class in a PD Data Frame.
pd.set_option('display.max_colwidth', -1)
df = pd.DataFrame({'query': query_data_train, 'intent': intent_data_train, 'slot filling': slot_data_train})

df_small = pd.DataFrame(columns=['query', 'intent', 'slot filling'])
j = 0
for i in df.intent.unique():
    df_small.loc[j] = df[df.intent == i].iloc[0]
    j = j + 1

print(df_small)

# Data Fields (B-depart_time.time, B-arrive_time.time, etc)
i2s_train_values = list(i2s_train.values())
df3 = pd.DataFrame()
for i in range(7):
  df3[str(i)] = i2s_train_values[i*15:(i+1)*15]
print(df3)

# 2) Create Tensors - by padding each query vector and slot vector to a maximum length.
# Queries is already tokenized and a vocabulary is also provided in the ATIS dataset.
# Queries have a start (“BOS”) and end (“EOS”) token.
input_data_train, teacher_data_train, target_data_train, \
len_input_train, len_target_train = pf.create_tensors(input_tensor_train, target_tensor_train)
input_data_test, teacher_data_test, target_data_test, \
len_input_test, len_target_test = pf.create_tensors(input_tensor_test, target_tensor_test, max_len=len_input_train)


vocab_in_size, vocab_out_size = pf.get_vocab_size(t2i_train, t2i_test, s2i_train, s2i_test)
print(vocab_in_size, vocab_out_size)

# 3) Building a Seq2Seq Model for Slot Filling
start_time = time.time()
model = pf.build_seq2seq(input_data_train, len_input_train, vocab_in_size, vocab_out_size)
print("--- Building seq2seq Model%s seconds ---" % (time.time() - start_time))

# 4) Training a Seq2Seq Model
# The validation accuracy starts to plateau around epoch 45, suggesting this model isn’t really inferring anymore and is starting overfitting.
start_time = time.time()
epochs = 50
BATCH_SIZE = 64
history = model.fit([input_data_train, teacher_data_train], target_data_train,
                    batch_size=BATCH_SIZE,
                    epochs=epochs,
                    validation_data=([input_data_test, teacher_data_test], target_data_test))

print("--- Training Model %s seconds ---" % (time.time() - start_time))
pf.plot_training_accuracy(history)




print("End")
